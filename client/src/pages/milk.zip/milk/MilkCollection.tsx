import { useState } from "react";
import { useFarmers } from "@/context/FarmersContext";
import { useAuth } from "@/context/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Eye, Edit, Calendar } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

export default function MilkCollection() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { farmers, refetchFarmers } = useFarmers();
  const { token } = useAuth();
  const [selectedDate, setSelectedDate] = useState("");
  const [mode, setMode] = useState<"new" | "edit" | "view">("new");
  const [lookupValue, setLookupValue] = useState("");
  const [collectionFarmers, setCollectionFarmers] = useState<Array<any>>([]);

  // Suggestions from local farmers list (simple client-side autocomplete)
  const suggestions = (lookupValue || "").trim()
    ? (() => {
      const term = (lookupValue || "").toLowerCase();
      // score and sort: memberNo prefix matches first, then name contains, then idNumber/phone
      return (farmers || [])
        .map((f: any) => {
          const fullName = `${(f.firstName || "").toLowerCase()} ${(f.surname || "").toLowerCase()}`;
          let score = 0;
          if ((f.memberNo || "").toLowerCase().startsWith(term)) score += 10;
          if (fullName.includes(term)) score += 5;
          if ((f.idNumber || "").toLowerCase().includes(term)) score += 3;
          if ((f.phone || "").toLowerCase().includes(term)) score += 2;
          if (score > 0) return { farmer: f, score };
          return null;
        })
        .filter(Boolean)
        .sort((a: any, b: any) => b.score - a.score)
        .map((s: any) => s.farmer)
        .slice(0, 8);
    })()
    : [];
  
  const mockDailyCollections = [
    { date: "2025-11-18", totalQuantity: 96.0, farmersCount: 4, avgFat: 3.8, avgSnf: 8.5, status: "completed" },
    { date: "2025-11-17", totalQuantity: 89.5, farmersCount: 4, avgFat: 3.7, avgSnf: 8.4, status: "completed" },
    { date: "2025-11-16", totalQuantity: 92.0, farmersCount: 3, avgFat: 3.9, avgSnf: 8.6, status: "completed" },
    { date: "2025-11-15", totalQuantity: 88.0, farmersCount: 4, avgFat: 3.8, avgSnf: 8.5, status: "completed" },
  ];

  const handleNewCollection = () => {
    setMode("new");
    setSelectedDate(new Date().toISOString().split('T')[0]);
    setIsDialogOpen(true);
  };

  const handleView = (date: string) => {
    setMode("view");
    setSelectedDate(date);
    setIsDialogOpen(true);
  };

  const handleEdit = (date: string) => {
    setMode("edit");
    setSelectedDate(date);
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    console.log("Saving collection for date:", selectedDate);
    toast({
      title: "Success",
      description: mode === "new" ? "Collection created successfully" : "Collection updated successfully",
    });
    setIsDialogOpen(false);
  };

  const handleGetFarmer = async () => {
    const term = lookupValue?.trim();
    if (!term) {
      toast({ title: "Lookup required", description: "Enter farmer _id, idNumber or phone to lookup", variant: "destructive" });
      return;
    }

    // Try local cache first (allow lookup by memberNo too)
    let found: any = farmers.find((f: any) => f._id === term || f.id === term || f.memberNo === term || f.idNumber === term || f.phone === term);

    if (!found) {
      // Try fetching by id
      try {
        const res = await fetch(`/api/farmers/${encodeURIComponent(term)}`);
        if (res.ok) found = await res.json();
      } catch (e) {
        // ignore
      }
    }

    if (!found) {
      // Fallback: fetch all and search by idNumber or phone
      try {
        const res2 = await fetch(`/api/farmers`);
        if (res2.ok) {
          const data = await res2.json();
          const list = data.farmers || data || [];
          found = list.find((f: any) => f.idNumber === term || f.phone === term || f.memberNo === term || `${f.firstName} ${f.surname}`.toLowerCase() === term.toLowerCase());
        }
      } catch (e) {
        // ignore
      }
    }

    if (!found) {
      toast({ title: "Not found", description: `No farmer matched '${term}'`, variant: "destructive" });
      return;
    }

    // Add to collection list if not already present
    setCollectionFarmers((prev) => {
      if (prev.some((p) => p.farmer?._id === found._id || p.farmer?.id === found._id)) return prev;
      return [...prev, { farmer: found, quantity: 0, fat: 0, snf: 0 }];
    });
    setLookupValue("");
  };

  const addFarmerToCollection = (found: any) => {
    if (!found) return;
    setCollectionFarmers((prev) => {
      if (prev.some((p) => p.farmer?._id === found._id || p.farmer?.id === found._id)) return prev;
      return [...prev, { farmer: found, quantity: 0, fat: 0, snf: 0 }];
    });
    setLookupValue("");
  };

  const handleRemoveCollectionFarmer = (idx: number) => {
    setCollectionFarmers((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSaveToServer = async () => {
    if (!selectedDate) {
      toast({ title: "Date required", description: "Pick a collection date", variant: "destructive" });
      return;
    }
    if (collectionFarmers.length === 0) {
      toast({ title: "No farmers", description: "Add at least one farmer to record collection", variant: "destructive" });
      return;
    }

    const payload = {
      date: selectedDate,
      entries: collectionFarmers.map((c) => ({ farmerId: c.farmer._id || c.farmer.id, quantity: Number(c.quantity) || 0, fat: Number(c.fat) || 0, snf: Number(c.snf) || 0 })),
    };

    try {
      // POST each entry to the server's /api/milk endpoint (server requires auth)
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (token) headers["Authorization"] = `Bearer ${token}`;

      for (const entry of payload.entries) {
        const r = await fetch(`/api/milk`, { method: "POST", headers, body: JSON.stringify({ farmerId: entry.farmerId, quantity: entry.quantity, fat: entry.fat, snf: entry.snf, date: payload.date }) });
        if (!r.ok) {
          const errorText = await r.text().catch(() => `HTTP ${r.status}`);
          throw new Error(`Entry save failed: ${errorText}`);
        }
      }

      toast({ title: "Saved", description: "Collection recorded successfully" });
      setIsDialogOpen(false);
      try { await refetchFarmers(); } catch (_) { }
      setCollectionFarmers([]);
    } catch (e: any) {
      console.error("Failed to save collection:", e);
      toast({ title: "Save failed", description: e?.message || "Could not save collection", variant: "destructive" });
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Milk Collection</h1>
        <Button onClick={handleNewCollection} data-testid="button-new-collection">
          <Plus className="h-4 w-4 mr-2" />
          New Collection
        </Button>
      </div>

 {/*}     <Card>
        <CardHeader>
          <CardTitle>Daily Collections</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    Date
                  </div>
                </TableHead>
                <TableHead>Total Quantity (L)</TableHead>
                <TableHead>Farmers</TableHead>
                <TableHead>Avg. Fat %</TableHead>
                <TableHead>Avg. SNF %</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockDailyCollections.map((collection) => (
                <TableRow key={collection.date} data-testid={`row-collection-${collection.date}`}>
                  <TableCell className="font-medium" data-testid={`text-date-${collection.date}`}>
                    {collection.date}
                  </TableCell>
                  <TableCell data-testid={`text-quantity-${collection.date}`}>
                    {collection.totalQuantity.toFixed(1)}
                  </TableCell>
                  <TableCell data-testid={`text-farmers-${collection.date}`}>
                    {collection.farmersCount}
                  </TableCell>
                  <TableCell data-testid={`text-fat-${collection.date}`}>
                    {collection.avgFat}
                  </TableCell>
                  <TableCell data-testid={`text-snf-${collection.date}`}>
                    {collection.avgSnf}
                  </TableCell>
                  <TableCell>
                    <Badge variant="default" data-testid={`badge-status-${collection.date}`}>
                      {collection.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleView(collection.date)}
                        data-testid={`button-view-${collection.date}`}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleEdit(collection.date)}
                        data-testid={`button-edit-${collection.date}`}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
*/}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-6xl w-full max-h-[95vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {mode === "new" ? "New Collection" : mode === "edit" ? "Edit Collection" : "View Collection"}
            </DialogTitle>
            <DialogDescription>
              {mode === "new" ? "Record milk collection for the day" : `Collection for ${selectedDate}`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="collection-date">Collection Date</Label>
              <Input
                id="collection-date"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                disabled={mode === "view"}
                data-testid="input-collection-date"
              />
            </div>

            <div>
              <h3 className="font-semibold mb-4">Farmer Collections</h3>

              {mode === "new" && (
                <div className="flex flex-col gap-2 mb-4">
                  <div className="flex gap-2 items-end">
                    <div className="flex-1">
                      <Label className="text-xs">Lookup Farmer (_id, ID no. or phone)</Label>
                      <Input value={lookupValue} onChange={(e) => setLookupValue(e.target.value)} placeholder="Type name, ID number, or phone" />
                    </div>
                    <div className="flex items-center gap-2">
                      <Button onClick={handleGetFarmer} className="h-9">Get Farmer</Button>
                      <Button variant="ghost" onClick={() => { setLookupValue(""); }}>Clear</Button>
                    </div>
                  </div>

                  {suggestions.length > 0 && (
                    <div className="bg-white border rounded shadow-sm max-h-48 overflow-auto">
                      {suggestions.map((s: any) => (
                        <div
                          key={s._id}
                          className="px-3 py-2 hover:bg-gray-100 cursor-pointer flex items-center justify-between"
                          onClick={() => addFarmerToCollection(s)}
                        >
                          <div>
                            <div className="font-medium">{s.firstName} {s.surname} <span className="text-xs text-muted-foreground">{s.memberNo || s.idNumber}</span></div>
                            <div className="text-xs text-gray-500">{s.phone}</div>
                          </div>
                          <div className="text-xs text-gray-400">Add</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Farmer</TableHead>
                    <TableHead>Quantity (L)</TableHead>
                    <TableHead>Fat %</TableHead>
                    <TableHead>SNF %</TableHead>
                    {mode !== "view" && <TableHead className="text-right">Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mode === "new" && collectionFarmers.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                        Add farmers to this collection using the lookup above
                      </TableCell>
                    </TableRow>
                  )}

                  {mode === "new" && collectionFarmers.map((c, idx) => (
                    <TableRow key={c.farmer._id || c.farmer.id}>
                      <TableCell>
                        <div className="font-medium">{c.farmer.firstName} {c.farmer.surname}</div>
                        <div className="text-xs text-muted-foreground">{c.farmer.memberNo || c.farmer.idNumber || c.farmer.phone}</div>
                      </TableCell>
                      <TableCell>
                        <Input type="number" step="0.1" value={c.quantity} onChange={(e) => setCollectionFarmers((prev) => { const copy = [...prev]; copy[idx].quantity = e.target.value; return copy; })} className="w-28" />
                      </TableCell>
                      <TableCell>
                        <Input type="number" step="0.1" value={c.fat} onChange={(e) => setCollectionFarmers((prev) => { const copy = [...prev]; copy[idx].fat = e.target.value; return copy; })} className="w-20" />
                      </TableCell>
                      <TableCell>
                        <Input type="number" step="0.1" value={c.snf} onChange={(e) => setCollectionFarmers((prev) => { const copy = [...prev]; copy[idx].snf = e.target.value; return copy; })} className="w-20" />
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" onClick={() => handleRemoveCollectionFarmer(idx)}>Remove</Button>
                      </TableCell>
                    </TableRow>
                  ))}

                {mode !== "new" && (
                    <>
                      <TableRow>
                        <TableCell>John Kamau</TableCell>
                        <TableCell>
                          {mode === "view" ? "25.5" : (
                            <Input type="number" step="0.1" defaultValue="25.5" className="w-24" />
                          )}
                        </TableCell>
                        <TableCell>
                          {mode === "view" ? "3.8" : (
                            <Input type="number" step="0.1" defaultValue="3.8" className="w-20" />
                          )}
                        </TableCell>
                        <TableCell>
                          {mode === "view" ? "8.5" : (
                            <Input type="number" step="0.1" defaultValue="8.5" className="w-20" />
                          )}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Mary Wanjiku</TableCell>
                        <TableCell>
                          {mode === "view" ? "30.0" : (
                            <Input type="number" step="0.1" defaultValue="30.0" className="w-24" />
                          )}
                        </TableCell>
                        <TableCell>
                          {mode === "view" ? "4.0" : (
                            <Input type="number" step="0.1" defaultValue="4.0" className="w-20" />
                          )}
                        </TableCell>
                        <TableCell>
                          {mode === "view" ? "8.7" : (
                            <Input type="number" step="0.1" defaultValue="8.7" className="w-20" />
                          )}
                        </TableCell>
                      </TableRow>
                    </>
                  )}
                </TableBody>
              </Table>
            </div>

            {mode !== "view" && (
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)} data-testid="button-cancel">
                  Cancel
                </Button>
                <Button onClick={handleSaveToServer} data-testid="button-save">
                  {mode === "new" ? "Create Collection" : "Save Changes"}
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
