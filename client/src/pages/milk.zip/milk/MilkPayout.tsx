import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";

export default function MilkPayout() {
  const { toast } = useToast();
  const [selectedFarmer, setSelectedFarmer] = useState("");
  const [period, setPeriod] = useState("");
  const [processing, setProcessing] = useState(false);
  const [report, setReport] = useState<any[]>([]);
  const { token } = useAuth();

  const mockFarmers: Array<{ id: string; name: string }> = [];

  const handleProcessPayout = async () => {
    if (!period) return toast({ title: "Select period", description: "Choose YYYY-MM period", variant: "destructive" });
    setProcessing(true);
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (token) headers["Authorization"] = `Bearer ${token}`;
      const res = await fetch(`/api/payouts/process?period=${encodeURIComponent(period)}`, { method: "POST", headers });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: res.statusText }));
        throw new Error(err.error || err.message || "Failed to process payouts");
      }
      const body = await res.json();
      const results = body.results || [];
      // enrich with farmer details
      const enriched: any[] = [];
      for (const r of results) {
        try {
          const fr = await fetch(`/api/farmers/${r.farmerId}`);
          const fj = await fr.json().catch(() => null);
          const farmer = fj?.farmer || null;
          enriched.push({ ...r, farmer });
        } catch (e) {
          enriched.push({ ...r, farmer: null });
        }
      }
      setReport(enriched);
      toast({ title: "Payouts Processed", description: `Processed payouts for ${body.period}` });
    } catch (err: any) {
      console.error("Error processing payouts:", err);
      toast({ title: "Error", description: err.message || "Failed to process payouts", variant: "destructive" });
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-6">Milk Payout</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Payout Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="farmer-select" data-testid="label-farmer">Select Farmer</Label>
              <Select value={selectedFarmer} onValueChange={setSelectedFarmer}>
                <SelectTrigger id="farmer-select" data-testid="select-farmer">
                  <SelectValue placeholder="Choose farmer" />
                </SelectTrigger>
                <SelectContent>
                  {mockFarmers.map((farmer) => (
                    <SelectItem key={farmer.id} value={farmer.id}>
                      {farmer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="period" data-testid="label-period">Period (YYYY-MM)</Label>
              <Input placeholder="2025-11" value={period} onChange={(e) => setPeriod(e.target.value)} />
            </div>

            <div className="pt-4 border-t space-y-3">
              <Button className="w-full" onClick={handleProcessPayout} disabled={processing} data-testid="button-process-payout">
                {processing ? "Processing…" : "Process Payouts for Period"}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Collection Details</CardTitle>
          </CardHeader>
          <CardContent>
            {report.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Member</TableHead>
                    <TableHead>Total Collected</TableHead>
                    <TableHead>Total Loan Deductions</TableHead>
                    <TableHead>Total Contributions</TableHead>
                    <TableHead className="text-right">Net Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {report.map((row: any) => (
                    <TableRow key={String(row.payoutId)}>
                      <TableCell>{row.farmer ? `${row.farmer.firstName} ${row.farmer.surname} (${row.farmer.memberNo})` : row.farmerId}</TableCell>
                      <TableCell>KES {Number(row.totalAmount).toFixed(2)}</TableCell>
                      <TableCell>KES {Number(row.totalLoanDeductions).toFixed(2)}</TableCell>
                      <TableCell>KES {Number(row.totalContributions).toFixed(2)}</TableCell>
                      <TableCell className="text-right font-bold">KES {Number(row.netAmount).toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-12 text-muted-foreground">No payout report yet. Select a period and click "Process Payouts".</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
